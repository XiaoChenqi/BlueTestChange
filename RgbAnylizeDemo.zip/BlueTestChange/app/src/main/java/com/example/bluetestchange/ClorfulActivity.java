package com.example.bluetestchange;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ClorfulActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clorful);
    }
}