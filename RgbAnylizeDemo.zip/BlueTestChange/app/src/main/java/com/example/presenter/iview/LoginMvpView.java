package com.example.presenter.iview;


import com.ezdata.commonlib.core.mvp.MvpView;

/**
 * Created by MSI-PC on 2018/6/29.
 */

public interface LoginMvpView extends MvpView {

    void nameNull();
    void pwdNull();
}
